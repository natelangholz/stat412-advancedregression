#####################################################################################################
#Engagement		-	UCLA MAS - STAT 412 - HW #2														#
#FileName		-	001_hw2_mk_data.r						  										#
#By				- 	Jeremy Guinta (ID 604882679)													#
#																	  								#
#Last Update Date:	4/28/2017									  									#
#																	  								#
#Purpose:		-	Build the data																	#											
#Notes:			- 	I hate lists :( 																#
#																									#
#####################################################################################################



#I. Setup -------------------------------------------------------------------------------------------

	#Remove Objects
	rm(list=ls())

	#Clear Memory
	gc(reset=TRUE)
	
	#Set Working Directory
	setwd("C:/Users/jguinta/Desktop/Working/005_GradSchool/003_Course/STAT412/HW2/")
	
	#Package Install
	require(grid)			#Plotting utilities
	require(gridExtra)		#Plotting utilities	
	require(tidyverse)		#All things tidy 
	require(data.table)		#Data table is better
	require(dtplyr)			#Make sure Data table and dplyr work together
	require(ggplot2)		#Graphing Utilities
	require(stringr)		#String Functions
	require(reshape2)		#Data Reshape
	require(GGally)			#Correlation

	#Set Options
	options(scipen=20)
	
	#Graphic Themes
		out_theme <- theme_bw() + 
		  theme(panel.grid.major=element_line(color="white"), 
				text=element_text(family="ArialMT"), 
				legend.position="bottom",
				plot.title = element_text(size = rel(1.0)),
				axis.text.x = element_text(size= rel(1.0)),
				axis.text.y = element_text(size= rel(1.0)))
				
		color_scheme <- c("#6495ED", "#C90E17", "#001933", "#691b14", "#08519c", "#778899", "#B0C4DE", 
							  "#999999", "#000000",  "#800000", "#B23232")   	
		
	#Custom Function
	prof_view<-function(dta, num=1 ) {
		require(tidyverse)
		require(data.table)
		require(dtplyr)
		require(ggplot2)
		require(grid)
		require(gridExtra)
		
		#input
		#dta = profile object 
		#num = number of the list object to view
		#
		
		#output - ggplot() 
		obj<-as.data.table(dta[[num]]$profile)
		setnames(obj, c("ord", "x", "y"))
		
		out1<-ggplot(obj, aes(ord, x))+geom_line(color="#6495ED")+theme_bw() + 
		  theme(panel.grid.major=element_line(color="white"), 
				text=element_text(family="ArialMT"), 
				legend.position="bottom",
				plot.title = element_text(size = rel(1.0)),
				axis.text.x = element_text(size= rel(1.0)),
				axis.text.y = element_text(size= rel(1.0)))
				
		out2<-ggplot(obj, aes(ord, y))+geom_line(color="#6495ED")+theme_bw() + 
		  theme(panel.grid.major=element_line(color="white"), 
				text=element_text(family="ArialMT"), 
				legend.position="bottom",
				plot.title = element_text(size = rel(1.0)),
				axis.text.x = element_text(size= rel(1.0)),
				axis.text.y = element_text(size= rel(1.0)))
	
		punch_type<-profiles[[num]]$punchtype
		if (is.null(punch_type)==TRUE) {
			punch_type<-"Unk"
		}
		out <- gridExtra::arrangeGrob(grobs = list(out1,out2),heights = c(1,1), ncol = 1, top=paste("Punch Type ",punch_type,  sep=""))
		return(out)
	}
		
							  
#II.  Data Loading ---------------------------------------------------------------------------------
load("./punch_profiles.Rdata")
load("./punch_types.RData")
punch_types<-as.data.table(punch_types)
punch_types[, event:=1:nrow(punch_types)]

#III. Data Exploration -----------------------------------------------------------------------------
set.seed(19790324)
val<-round(runif(10,1,600),0) #Ten randomly selected profiles
							  #Picking one through 600 as the profiles after 600 do not have a punch type (in the profile data)

for (i in val) { 
	out<-prof_view(profiles, num=i)
	ggsave(file=paste("./out", i, ".pdf", sep=""), out, height=8, width=11)
}

#IV. Data Processing ------------------------------------------------------------------------------

#A. Build a loop to flip each profile into ACTUAL DATA (ugh, Lists)

j<-1

for (i in 1:length(profiles)) {
	print(j)
	
	#X,Y Data
	dta<-as.data.table(profiles[[j]]$profile)
	setnames(dta, c("ord", "x", "y"))
	
	#Time Differences
	td<-as.data.table(profiles[[j]]$time_differences)
	stopifnot(nrow(td)==2)
	td[, ord:=1:nrow(td)]
	td1<-td[ord==1, .(beg=V1)]
	td2<-td[ord==2, .(fin=V1)]
	td<-cbind(td1,td2)
	dta<-cbind(dta,td) #Add Time Difference

	#Add hand
	hand<-as.data.table(profiles[[j]]$hand)
	setnames(hand, "hand")
	dta<-cbind(dta,hand)	#Add hand
	
	#Add Samples
	samp<-as.data.table(profiles[[j]]$samples)
	setnames(samp, "samp")
	dta<-cbind(dta,samp) #Add samples

	dta[, event:=j] #Add Event ID.  This will be used to link to punch type from the other file
	
	if (j ==1) {
		out<-dta
	}
	else {
		out<-rbind(out, dta)
	}
	j<-j+1
}

#B. Add Punch Type 
	setkey(out, event)
	setkey(punch_types, event)
	punch_types[, hand_pt:=hand]
	punch_types[, hand:=NULL]
	
	out<-out[punch_types, nomatch=0] #Data table inner join
	cnt<-out[hand!=hand_pt, .N]
	stopifnot(cnt==0)
	out[, hand_pt:=NULL]
	
#V. Data Output ------------------------------------------------------------------------------
saveRDS(file="./punch_raw.rds", out)

	