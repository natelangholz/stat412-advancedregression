#####################################################################################################
#Engagement		-	UCLA MAS - STAT 412 - HW #2														#
#FileName		-	003_an_model.r						  											#
#By				- 	Jeremy Guinta (ID 604882679)													#
#																	  								#
#Last Update Date:	4/28/2017									  									#
#																	  								#
#Purpose:		-	Run ML models																	#											
#Notes:			- 																					#
#				- Outcome prediction: 																#
#																									#
#				1 - Cross																			#
#				2 - Hook																			#
#				3 - Jab																				#
#				4 - Upper Cut																		#
#				5 - Overhand (shouldn't be any of these)											#
#				6 - Unknown (shouldn't be any of these)												#
#																									#
#####################################################################################################



#I. Setup -------------------------------------------------------------------------------------------

	#Remove Objects
	rm(list=ls())

	#Clear Memory
	gc(reset=TRUE)
	
	#Set Working Directory
	#setwd("C:/Users/jguinta/Desktop/Working/005_GradSchool/003_Course/STAT412/HW2/")
	setwd("//chi1fls02/tsp/LosAngeles/Admin/001_Users/jjg/STAT412/HW2/")
	
	#Package Install
	require(grid)			#Plotting utilities
	require(gridExtra)		#Plotting utilities	
	require(tidyverse)		#All things tidy 
	require(data.table)		#Data table is better
	require(dtplyr)			#Make sure Data table and dplyr work together
	require(ggplot2)		#Graphing Utilities
	require(stringr)		#String Functions
	require(reshape2)		#Data Reshape
	require(h2o)			#h2o Machine Learning

	#Set Options
	options(scipen=20)
	
	#Graphic Themes
		out_theme <- theme_bw() + 
		  theme(panel.grid.major=element_line(color="white"), 
				text=element_text(family="ArialMT"), 
				legend.position="bottom",
				plot.title = element_text(size = rel(1.0)),
				axis.text.x = element_text(size= rel(1.0)),
				axis.text.y = element_text(size= rel(1.0)))
				
		color_scheme <- c("#6495ED", "#C90E17", "#001933", "#691b14", "#08519c", "#778899", "#B0C4DE", 
							  "#999999", "#000000",  "#800000", "#B23232")   	
									  
#II.  Data Loading ---------------------------------------------------------------------------------
feat<-readRDS("./feat.rds")
feat[, pt_label:=ifelse(pt==1, "Cross", ifelse(pt==2, "Hook", ifelse(pt==3, "Jab", ifelse(pt==4, "Upper Cut", NA)))),]


#III. Data Processing ------------------------------------------------------------------------------
#A. Prepare the data for h2o

	setwd("C:/h2o/")  	#The network pathways are too long.  Setting directory to local C:/h2o
						#All h2o objects will be saved here	
	h2o.init(nthreads=6)
	feat[, pt:=NULL]
	write.csv(file="./feat.csv", feat)
	
	#Load into h2o
	feat<-h2o.importFile("./feat.csv")
	
#B. Set up Grid Search 
		xnames <- names(feat[grepl("event|pt|C1|samp|beg|fin", names(feat))==FALSE])

		#1. Generalize Linear Models (Multinomial) - GLM

		hyper_params_glm <- list(
		  alpha = c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1)
		)
      
		#2. Gradient Boosted Model - GBM
		
		hyper_params_gbm <- list(
		  ntrees = c(500,1000,1500,2000,2500), 
		  max_depth = 5:25, 
		  min_rows = c(10,30,70,100), 
		  learn_rate = c(.01,.03,.05,.08,.1),
		  sample_rate = c(.975,.99,.995,1),
		  col_sample_rate = c(.4,.7,1,1),
		  col_sample_rate_per_tree = c(.7,1,1),
		  nbins_cats = c(64,256,1024)
		)
		
		#3. Deep Learning - Neural Net - NN
		
		hyper_params_nn <- list(
		  epochs=100,
		  hidden=c(100,100),
		  max_w2=10,
		  activation=c("Tanh"),
		  l1=c(.00001,.000001,.0000001),
		  l2=c(.00001,.000001,.0000001),
		  rho = c(.99,.90,1,0.95),
		  rate=c(.005,.0005,.00005),
		  rate_annealing=c(.00000001,.0000001,.000001,.00001),
		  momentum_start=c(.5,.1,.01,.005),
		  momentum_stable=c(1000000,100000), 
		  momentum_ramp=c(.99,.98,.97,.96,.95)
		)
		
		#4. GLM/GBM/NN Search Criteria
		search_criteria <- list(
		  strategy = "RandomDiscrete",
		  max_runtime_secs = 7200,  #2 hours per run
		  max_models = 500
		)	
		
		#5. Interaction List 
		interaction_list<-c("mxx",          "mxy",          "mnx",         
						"mny",          "mxx_ordls0",   "mxy_ordls0",   "mnx_ordls0",  
						"mny_ordls0",   "mxx_ordgt0",   "mnx_ordgt0",   "mxy_ordgt0",  
						"mny_ordgt0",   "tot_tm_x",     "tot_tm_imp_x", "tot_tm_y",    
						"tot_tm_imp_y", "tot_dis_x",    "tot_dis_y", "avgx", "avgy", "medx", "medy")	

#C. Generate the models
	#1. Multinomial 
		glm1 <- h2o.grid(algorithm = "glm", 
							x = xnames, y = "pt_label", 
							training_frame = feat,
							hyper_params = hyper_params_glm,
							search_criteria = search_criteria,
							stopping_metric = "mean_per_class_error", stopping_tolerance = 1e-3, 
							stopping_rounds = 3,
							seed = 1,
							nfolds = 5, fold_assignment = "Modulo", 
							keep_cross_validation_predictions = TRUE,
							family = "multinomial",
							lambda_search=TRUE,
							interactions=interaction_list
							)
							
		glm1_sort <- h2o.getGrid(grid_id = glm1@grid_id, sort_by = "mean_per_class_error", decreasing = FALSE)
		glm1_best <- h2o.getModel(glm1_sort@model_ids[[1]])
		summary(glm1_best)		
		glm1_conf_matrix<-as.data.frame(h2o.confusionMatrix(glm1_best))
		
		glm1_coef<-as.data.frame(glm1_best@model$coefficients_table)	

	#2. GBM - Professor never said NOT to run a GBM :D
		gbm1 <- h2o.grid(algorithm = "gbm", 
		                x = xnames, y = "pt_label", 
		                training_frame = feat,
		                hyper_params = hyper_params_gbm,
		                search_criteria = search_criteria,
		                stopping_metric = "mean_per_class_error", stopping_tolerance = 1e-3, 
		                stopping_rounds = 5,
		                seed = 1,
		                nfolds = 5, fold_assignment = "Modulo", 
		                keep_cross_validation_predictions = TRUE,
						distribution ="multinomial"
		)
		
		gbm1_sort <- h2o.getGrid(grid_id = gbm1@grid_id, sort_by = "mean_per_class_error", decreasing = FALSE)
		gbm1_best <- h2o.getModel(gbm1_sort@model_ids[[1]])
		gbm1_conf_matrix<-as.data.frame(h2o.confusionMatrix(gbm1_best))
		
		gbm1_best <- h2o.getModel(gbm1_sort@model_ids[[1]])
		summary(gbm1_best)	

	#3. Deep Learning NN (Total overkill and not much data to run this, but really curious if 
	#					  there will be better results)
	
		nn1 <- h2o.grid(algorithm = "deeplearning", 
		                x = xnames, y = "pt_label", 
		                training_frame = feat,
		                hyper_params = hyper_params_nn,
		                search_criteria = search_criteria,
		                stopping_metric = "mean_per_class_error", stopping_tolerance = 1e-3, 
		                stopping_rounds = 3,
		                seed = 1,
		                nfolds = 5, fold_assignment = "Modulo", 
		                keep_cross_validation_predictions = TRUE
		)
		
		nn1_sort <- h2o.getGrid(grid_id = nn1@grid_id, sort_by = "mean_per_class_error", decreasing = FALSE)
		nn1_sort
		
		nn1_best <- h2o.getModel(nn1_sort@model_ids[[1]])
		summary(nn1_best)	
		
		#Summary Output	
		nn1_conf_matrix<-as.data.frame(h2o.confusionMatrix(nn1_best))	

#IV. Output
	#A. Save Models
		glm1_best_save <- h2o.saveModel(
		  object = glm1_best,
		  path = "//chi1fls02/tsp/LosAngeles/Admin/001_Users/jjg/STAT412/HW2/glm1.h2o", 
		  force =TRUE
		)
		
		gbm1_best_save <- h2o.saveModel(
		  object = gbm1_best,
		  path = "//chi1fls02/tsp/LosAngeles/Admin/001_Users/jjg/STAT412/HW2/gbm1.h2o", 
		  force =TRUE
		)
		
		nn1_best_save <- h2o.saveModel(
		  object = nn1_best,
		  path = "//chi1fls02/tsp/LosAngeles/Admin/001_Users/jjg/STAT412/HW2/nn1.h2o", 
		  force =TRUE
		)
		
		save(file="003_model_paths.h2o", glm1_best_save, gbm1_best_save, nn1_best_save)

	