#####################################################################################################
#Engagement		-	UCLA MAS - STAT 412 - HW #3														#
#FileName		-	002_mk_feat.r							  										#
#By				- 	Jeremy Guinta (ID 604882679)													#
#																	  								#
#Last Update Date:	5/23/2017									  									#
#																	  								#
#Purpose:		-	Build features from the data													#											
#Notes:			- 																					#
#																									#
#####################################################################################################



#I. Setup -------------------------------------------------------------------------------------------

	#Remove Objects
	rm(list=ls())

	#Clear Memory
	gc(reset=TRUE)
	
	#Set Working Directory
#	setwd("C:/Users/jguinta/Desktop/Working/005_GradSchool/003_Course/STAT412/HW3/")
	setwd("//chi1fls02/tsp/LosAngeles/Admin/001_Users/jjg/STAT412/HW3/")
	
	#Package Install
	require(grid)			#Plotting utilities
	require(gridExtra)		#Plotting utilities	
	require(tidyverse)		#All things tidy 
	require(data.table)		#Data table is better
	require(dtplyr)			#Make sure Data table and dplyr work together
	require(ggplot2)		#Graphing Utilities
	require(stringr)		#String Functions
	require(reshape2)		#Data Reshape
	require(GGally)			#Correlation

	#Set Options
	options(scipen=20)
	
	#Graphic Themes
		out_theme <- theme_bw() + 
		  theme(panel.grid.major=element_line(color="white"), 
				text=element_text(family="ArialMT"), 
				legend.position="bottom",
				plot.title = element_text(size = rel(1.0)),
				axis.text.x = element_text(size= rel(1.0)),
				axis.text.y = element_text(size= rel(1.0)))
				
		color_scheme <- c("#6495ED", "#C90E17", "#001933", "#691b14", "#08519c", "#778899", "#B0C4DE", 
							  "#999999", "#000000",  "#800000", "#B23232")   	
									  
#II.  Data Loading ---------------------------------------------------------------------------------
pnch<-readRDS("./punch_raw.rds")

#III. Data Processing ------------------------------------------------------------------------------

#A. Features

	#1. Build base features
	feat_all<-pnch[ord> -250 & ord<250, list(
			mxx=max(x)
		,	mxy=max(y)
		,	mnx=min(x)
		,	mny=min(y)
		)
		,	by=list(event)]

	feat_ls0<-pnch[ord> -250 & ord<0, list(
			mxx_ordls0=max(ifelse(ord<0,max(x),NA), na.rm=TRUE)
		,	mxy_ordls0=max(ifelse(ord<0,max(y),NA), na.rm=TRUE)
		,	mnx_ordls0=max(ifelse(ord<0,min(x),NA), na.rm=TRUE)
		,	mny_ordls0=max(ifelse(ord<0,min(y),NA), na.rm=TRUE)
		)
		,	by=list(event)]

	feat_gt0x<-pnch[ord>=0 & ord<100 & x>0, list(		
			mxx_ordgt0=max(ifelse(ord>=0,max(x),NA), na.rm=TRUE)
		,	mnx_ordgt0=max(ifelse(ord>=0,min(x),NA), na.rm=TRUE)
		)
		,	by=list(event)]
		
	feat_gt0y<-pnch[ord>=0 & ord<100 & y>0, list(		
			mxy_ordgt0=max(ifelse(ord>=0,max(y),NA), na.rm=TRUE)
		,	mny_ordgt0=max(ifelse(ord>=0,min(y),NA), na.rm=TRUE)
		)
		,	by=list(event)]
		
	nrow(feat_gt0y)
	
	#Find the 5 missing events.  Fix and add back to the feat_gt0y
	gty<-as.data.table(unique(feat_gt0y$event))
	setnames(gty, "event")
	gty[, gty:=1]
	evt<-as.data.table(unique(pnch$event))
	setnames(evt, "event")
	evt[, evt:=1]
	
	chk<-merge(evt, gty, by.x=c("event"), by.y=c("event"), all=TRUE)
	chk[, .N, by=list(gty, evt)]
	lst<-as.vector(as.matrix(chk[is.na(gty)==TRUE, .(event)]))

	feat_gt0y2<-pnch[ord>=0 & event %in% c(lst), list(		
		mxy_ordgt0=max(ifelse(ord>=0,max(y),NA), na.rm=TRUE)
	,	mny_ordgt0=max(ifelse(ord>=0,min(y),NA), na.rm=TRUE)
	)
	,	by=list(event)]
	
	feat_gt0y<-rbind(feat_gt0y, feat_gt0y2)
	
	feat<-inner_join(feat_all, feat_ls0, by=c("event"="event"))
	feat<-inner_join(feat, feat_gt0x, by=c("event"="event"))
	feat<-inner_join(feat, feat_gt0y, by=c("event"="event"))
	feat<-as.data.table(feat)
	
	stopifnot(nrow(feat)==length(unique(pnch$event)))

#B. Build time to punch features
	
	#X	
	
	#1. This will capture the ord at the lowest x value before the peak 
	tmp<-as.data.table(inner_join(as.data.frame(pnch[ord<0,]), as.data.frame(feat), by=c("event"="event", "x"="mnx_ordls0")))  #Before Peak X
	tmp<-tmp[, list(mnx_ls_peak_ord=max(ord)),by=list(event)]
	mnx_ls_peak<-tmp[, .(event, mnx_ls_peak_ord)]
	stopifnot(nrow(mnx_ls_peak)==length(unique(pnch$event)))
	
	#2. This will capture the ord at the peak value 
	tmp<-as.data.table(inner_join(as.data.frame(pnch), as.data.frame(feat), by=c("event"="event", "x"="mxx")))  #At Peak Max X
	tmp<-tmp[, list(mxx_peak_ord=max(ord)),by=list(event)]
	mxx_peak<-tmp[, .(event, mxx_peak_ord)]
	stopifnot(nrow(mxx_peak)==length(unique(pnch$event)))

	#3. This will capture the ord at the lowest x after the peak
	tmp<-as.data.table(inner_join(as.data.frame(pnch[ord>=0 & ord<=100 & x>0]), as.data.frame(feat), by=c("event"="event", "x"="mnx_ordgt0")))  #After Peak X
	tmp<-tmp[, list(mnx_gt_peak_ord=max(ord)),by=list(event)]
	mnx_gt_peak<-tmp[, .(event, mnx_gt_peak_ord)]
	stopifnot(nrow(mnx_gt_peak)==length(unique(pnch$event)))
	
	#Y

	#4. This will capture the ord at the lowest y value before the peak 
	tmp<-as.data.table(inner_join(as.data.frame(pnch[ord<0,]), as.data.frame(feat), by=c("event"="event", "y"="mny_ordls0")))  #Before Peak X
	tmp<-tmp[, list(mny_ls_peak_ord=max(ord)),by=list(event)]
	mny_ls_peak<-tmp[, .(event, mny_ls_peak_ord)]
	stopifnot(nrow(mny_ls_peak)==length(unique(pnch$event)))
	
	#5. This will capture the ord at the peak value 
	tmp<-as.data.table(inner_join(as.data.frame(pnch), as.data.frame(feat), by=c("event"="event", "y"="mxy")))  #At Peak Max X
	tmp<-tmp[, list(mxy_peak_ord=max(ord)),by=list(event)]
	mxy_peak<-tmp[, .(event, mxy_peak_ord)]
	stopifnot(nrow(mxy_peak)==length(unique(pnch$event)))

	#6. This will capture the ord at the lowest y after the peak
	tmp<-as.data.table(inner_join(as.data.frame(pnch[ord>=0 & ord<=100 & y>0]), as.data.frame(feat), by=c("event"="event", "y"="mny_ordgt0")))  #After Peak X
	tmp<-tmp[, list(mny_gt_peak_ord=max(ord)),by=list(event)]
	mny_gt_peak1<-tmp[, .(event, mny_gt_peak_ord)]

	tmp<-as.data.table(inner_join(as.data.frame(pnch[ord>=0 & event %in% c(lst)]), as.data.frame(feat), by=c("event"="event", "y"="mny_ordgt0")))  #After Peak X
	tmp<-tmp[, list(mny_gt_peak_ord=max(ord)),by=list(event)]
	mny_gt_peak2<-tmp[, .(event, mny_gt_peak_ord)]
	
	mny_gt_peak<-rbind(mny_gt_peak1, mny_gt_peak2)
	
	stopifnot(nrow(mny_gt_peak)==length(unique(pnch$event)))
	
	#Combine
	tm<-inner_join(mnx_ls_peak, mxx_peak, by=c("event"="event"))
	tm<-inner_join(tm, mnx_gt_peak, by=c("event"="event"))
	tm<-inner_join(tm, mny_ls_peak, by=c("event"="event"))
	tm<-inner_join(tm, mxy_peak, by=c("event"="event"))
	tm<-inner_join(tm, mny_gt_peak, by=c("event"="event"))
	
	tm<-as.data.table(tm)
	
	tm[, tot_tm_x:=abs(mnx_ls_peak_ord)+abs(mnx_gt_peak_ord)] #Total Time to punch on x
	tm[, tot_tm_imp_x:=abs(mnx_ls_peak_ord)+abs(mxx_peak_ord)] #Total Time to Impact on x
	
	tm[, tot_tm_y:=abs(mny_ls_peak_ord)+abs(mny_gt_peak_ord)] #Total Time to punch on y
	tm[, tot_tm_imp_y:=abs(mny_ls_peak_ord)+abs(mxy_peak_ord)] #Total Time to Impact on y
	tm<-tm[, .(event, tot_tm_x, tot_tm_imp_x, tot_tm_y, tot_tm_imp_y)]

	
#D. Build Distance to Punch Feature set
	
	#X	
	
	#1. This will capture the X at the lowest x value before the peak 
	tmp<-as.data.table(inner_join(as.data.frame(pnch[ord<0,]), as.data.frame(feat), by=c("event"="event", "x"="mnx_ordls0")))  #Before Peak X
	tmp<-tmp[, list(mnx_ls_peak_x=max(x)),by=list(event)]
	mnx_ls_peak<-tmp[, .(event, mnx_ls_peak_x)]
	stopifnot(nrow(mnx_ls_peak)==length(unique(pnch$event)))
	
	#2. This will capture the X at the peak value 
	tmp<-as.data.table(inner_join(as.data.frame(pnch), as.data.frame(feat), by=c("event"="event", "x"="mxx")))  #At Peak Max X
	tmp<-tmp[, list(mxx_peak_x=max(x)),by=list(event)]
	mxx_peak<-tmp[, .(event, mxx_peak_x)]
	stopifnot(nrow(mxx_peak)==length(unique(pnch$event)))

	#3. This will capture the X at the lowest x after the peak
	tmp<-as.data.table(inner_join(as.data.frame(pnch[ord>=0 & ord<=100 & x>0]), as.data.frame(feat), by=c("event"="event", "x"="mnx_ordgt0")))  #After Peak X
	tmp<-tmp[, list(mnx_gt_peak_x=max(x)),by=list(event)]
	mnx_gt_peak<-tmp[, .(event, mnx_gt_peak_x)]
	stopifnot(nrow(mnx_gt_peak)==length(unique(pnch$event)))
	
	#Y

	#4. This will capture the Y at the lowest y value before the peak 
	tmp<-as.data.table(inner_join(as.data.frame(pnch[ord<0,]), as.data.frame(feat), by=c("event"="event", "y"="mny_ordls0")))  #Before Peak X
	tmp<-tmp[, list(mny_ls_peak_y=max(y)),by=list(event)]
	mny_ls_peak<-tmp[, .(event, mny_ls_peak_y)]
	stopifnot(nrow(mny_ls_peak)==length(unique(pnch$event)))
	
	#5. This will capture the Y at the peak value 
	tmp<-as.data.table(inner_join(as.data.frame(pnch), as.data.frame(feat), by=c("event"="event", "y"="mxy")))  #At Peak Max X
	tmp<-tmp[, list(mxy_peak_y=max(y)),by=list(event)]
	mxy_peak<-tmp[, .(event, mxy_peak_y)]
	stopifnot(nrow(mxy_peak)==length(unique(pnch$event)))

	#6. This will capture the Y at the lowest y after the peak
	tmp<-as.data.table(inner_join(as.data.frame(pnch[ord>=0 & ord<=100 & y>0]), as.data.frame(feat), by=c("event"="event", "y"="mny_ordgt0")))  #After Peak X
	tmp<-tmp[, list(mny_gt_peak_y=max(y)),by=list(event)]
	mny_gt_peak1<-tmp[, .(event, mny_gt_peak_y)]

	tmp<-as.data.table(inner_join(as.data.frame(pnch[ord>=0 & event %in% c(lst)]), as.data.frame(feat), by=c("event"="event", "y"="mny_ordgt0")))  #After Peak X
	tmp<-tmp[, list(mny_gt_peak_y=max(y)),by=list(event)]
	mny_gt_peak2<-tmp[, .(event, mny_gt_peak_y)]
	
	mny_gt_peak<-rbind(mny_gt_peak1, mny_gt_peak2)
	
	stopifnot(nrow(mny_gt_peak)==length(unique(pnch$event)))
	
	#Combine
	dis<-inner_join(mnx_ls_peak, mxx_peak, by=c("event"="event"))
	dis<-inner_join(dis, mnx_gt_peak, by=c("event"="event"))
	dis<-inner_join(dis, mny_ls_peak, by=c("event"="event"))
	dis<-inner_join(dis, mxy_peak, by=c("event"="event"))
	dis<-inner_join(dis, mny_gt_peak, by=c("event"="event"))
	
	dis<-as.data.table(dis)
	
	dis[, tot_dis_x:=abs(mnx_ls_peak_x)+abs(mnx_gt_peak_x)] #Total distance to punch on x
	
	dis[, tot_dis_y:=abs(mny_ls_peak_y)+abs(mny_gt_peak_y)] #Total distance to punch on y
	
	dis<-dis[, .(event, tot_dis_x, tot_dis_y)]

#E. Average X, Y
	avgx<-pnch[ord> -50 & ord < 50 & x>0
				, list(avgx=mean(x),
					   medx=median(x)
				)
				
			, by=event]
	stopifnot(nrow(avgx)==length(unique(pnch$event)))
	avgy<-pnch[ord> -50 & ord < 50 & y>0
				, list(avgy=mean(y),
					   medy=median(y)
				)
				
			, by=event]
	#stopifnot(nrow(avgy)==length(unique(pnch$event)))  #There are events that only have negative values between -50 and 50
	
	missy<-avgy[, .(event)]
	missy[, missy:=1]
	
	allevt<-unique(pnch[, .(event)], by=c("event"))
	allevt[, allevt:=1]
	
	missy<-as.data.table(full_join(missy, allevt, by=c("event"="event")))
	missy[, .N, by=list(allevt, missy)]

	missy<-as.matrix(missy[allevt==1 & is.na(missy)==TRUE,.(event)])
	
	avgy2<-pnch[ord> -50 & ord< 50 & event %in% c(missy), list(avgy=mean(y), medy=median(y)), by=event]
	avgy<-rbind(avgy, avgy2)
	stopifnot(nrow(avgy)==length(unique(pnch$event)))

#F. Build Feature Set
	feat_final<-merge(feat, tm, by=c("event"), all=FALSE)
	feat_final<-merge(feat_final, dis, by=c("event"), all=FALSE)
	feat_final<-merge(feat_final, avgx, by=c("event"), all=FALSE)
	feat_final<-merge(feat_final, avgy, by=c("event"), all=FALSE)
	
	stopifnot(nrow(feat_final)==length(unique(pnch$event)))
	
#G. Add back to original features
	pnch<-unique(pnch[, .(event, boxer, boxer.order, bag.weight, gender, commitment, stance, hours.training, glove.weight, height, weight,
					wingspan, armlength.hit, bicep.hit, elbow.hit, forearm.hit, wrist.hit, armweight.hit, glove.tape, tests, i.hand, 
					punch.type, hands, force)], 
				by=c("event", "boxer", "boxer.order", "bag.weight", "gender", "commitment", "stance", "hours.training", "glove.weight", "height", "weight",
					"wingspan", "armlength.hit", "bicep.hit", "elbow.hit", "forearm.hit", "wrist.hit", "armweight.hit", "glove.tape", "tests", "i.hand", 
					"punch.type", "hands", "force"))

	setkey(feat_final, event)
	setkey(pnch, event)
	feat_final<-feat_final[pnch, nomatch=0]
	stopifnot(nrow(feat_final)==1000)
			
#IV. Data Analysis ----------------------------------------------------------------------------------------
	
#V. Data Output
	saveRDS(file="./feat.rds", feat_final)
